package `in`.dhirendra.stormcontrol

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var battery: TextView
    private lateinit var audio: AudioManager
    private val deviceName = "Mivi DuoPods Storm"

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED") {
                val level = intent.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL", -1)
                if (level in 0..100) battery.text = "Battery reported by Android: $level%"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        buildScreen()
        requestBluetoothPermissionIfNeeded()
        registerBatteryReceiver()
        refreshDeviceInfo()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 42, 32, 24)
            setBackgroundColor(0xFF101820.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                setPadding(0, 10, 0, 10)
            }
        page.addView(label("STORM CONTROL", 27f))
        page.addView(label("Mivi DuoPods Storm companion (unofficial)", 14f, 0xFFB9C6D2.toInt()))
        status = label("Checking Bluetooth…", 16f, 0xFF67E0C0.toInt())
        page.addView(status)
        battery = label("Battery: Android may not expose earbud battery on every phone.", 14f, 0xFFE5EAF0.toInt())
        page.addView(battery)

        page.addView(label("MUSIC CONTROLS", 18f, 0xFF67E0C0.toInt()))
        page.addView(actionButton("Play / Pause") { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) })
        page.addView(actionButton("Next track") { mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT) })
        page.addView(actionButton("Previous track") { mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS) })

        page.addView(label("PHONE VOLUME", 18f, 0xFF67E0C0.toInt()))
        page.addView(actionButton("Volume +") { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) })
        page.addView(actionButton("Volume −") { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) })

        page.addView(label("DEVICE-SPECIFIC FEATURES", 18f, 0xFF67E0C0.toInt()))
        page.addView(label("Gaming Mode, touch remapping and earbud EQ are not enabled here. The manual documents touch gestures, but does not provide a Bluetooth command protocol for controlling them from an app.", 14f, 0xFFE5EAF0.toInt()))
        page.addView(actionButton("Refresh Bluetooth status") { refreshDeviceInfo() })
        page.addView(label("Note: this app sends standard Android media commands. It cannot guarantee control of every music player.", 12f, 0xFFB9C6D2.toInt()))

        setContentView(page)
    }

    private fun actionButton(title: String, action: () -> Unit): Button =
        Button(this).apply {
            text = title
            isAllCaps = false
            textSize = 16f
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 8 }
        }

    private fun mediaKey(code: Int) {
        val now = android.os.SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0))
        Toast.makeText(this, "Media command sent", Toast.LENGTH_SHORT).show()
    }

    private fun requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 41)
        }
    }

    private fun registerBatteryReceiver() {
        val filter = IntentFilter("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(batteryReceiver, filter)
    }

    private fun refreshDeviceInfo() {
        try {
            val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
            val adapter: BluetoothAdapter? = manager.adapter
            if (adapter == null || !adapter.isEnabled) {
                status.text = "Bluetooth is off"
                return
            }
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                status.text = "Allow Nearby devices permission, then refresh."
                return
            }
            val found = adapter.bondedDevices?.any { it.name == deviceName } == true
            status.text = if (found) "Paired device found: $deviceName" else "Device not found in paired devices. Pair it in Android Bluetooth settings first."
        } catch (e: SecurityException) {
            status.text = "Bluetooth permission is required."
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
