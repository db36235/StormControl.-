# Storm Control (Unofficial Android starter app)

यह Mivi DuoPods Storm के लिए एक शुरुआती Android प्रोजेक्ट है।

## अभी क्या करता है
- Android Bluetooth में paired device `Mivi DuoPods Storm` मौजूद है या नहीं, यह दिखाता है।
- Android के standard media commands भेजता है: Play/Pause, Next, Previous।
- फोन के media volume को बढ़ाता/घटाता है।
- Android से आने वाले Bluetooth battery-level broadcast को सुनने की कोशिश करता है। हर फोन/ईयरबड इस battery broadcast को उपलब्ध नहीं कराता।

## अभी क्या नहीं करता
- Gaming Mode को ऐप से चालू/बंद नहीं करता।
- Earbud touch gestures को remap नहीं करता।
- Earbud firmware EQ या ANC जैसी proprietary settings नहीं बदलता।
- बैटरी प्रतिशत दिखने की गारंटी नहीं है।

तुम्हारे दिए User Manual में Gaming Mode के लिए बायाँ earbud तीन बार touch, Voice Assistant के लिए दायाँ earbud तीन बार touch, volume के लिए press-and-hold, Next के लिए दायाँ दो बार और Previous के लिए बायाँ दो बार लिखा है। Manual में app-to-earbud control protocol नहीं दिया गया है।

## APK बनाने के लिए
इस प्रोजेक्ट को Android Studio में खोलें। Android SDK Platform 35 और JDK 17 चाहिए। Gradle sync होने दें, फिर:
Build > Build Bundle(s) / APK(s) > Build APK(s)

APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनेगी।

यह प्रोजेक्ट अभी इस वातावरण में compile या device-test नहीं किया गया है। पहले APK को अपने फोन पर टेस्ट करें। यह unofficial app है और Mivi से संबद्ध नहीं है।
