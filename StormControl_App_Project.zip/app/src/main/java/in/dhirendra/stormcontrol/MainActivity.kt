package `in`.dhirendra.stormcontrol

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var audio: AudioManager
    private lateinit var statusText: TextView
    private lateinit var batteryText: TextView
    private lateinit var volumeText: TextView
    private lateinit var volumeBar: SeekBar
    private val deviceName = "Mivi DuoPods Storm"
    private val bg = Color.rgb(10, 15, 25)
    private val card = Color.rgb(20, 29, 44)
    private val accent = Color.rgb(64, 220, 180)
    private val muted = Color.rgb(166, 181, 199)

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED") {
                val level = intent.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL", -1)
                if (level in 0..100) batteryText.text = "Android battery report: $level%"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
        registerBatteryReceiver()
        requestBluetoothPermissionIfNeeded()
        refreshDeviceInfo()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
        }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(content)

        content.addView(text("STORM CONTROL", 27f, accent, true))
        content.addView(text("Mivi DuoPods Storm  •  Unofficial companion", 13f, muted))
        addGap(content, 18)

        val deviceCard = card(content, "DEVICE STATUS", "Check Bluetooth pairing and permission")
        statusText = text("Checking Bluetooth…", 15f, accent, true)
        deviceCard.addView(statusText)
        batteryText = text("Earbud battery: Android may not expose this information on every phone.", 13f, muted)
        deviceCard.addView(batteryText)
        addButton(deviceCard, "Refresh device status") { refreshDeviceInfo() }
        addButton(deviceCard, "Open Bluetooth settings") {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }

        val mediaCard = card(content, "MUSIC CONTROLS", "Sends standard Android media commands")
        addButton(mediaCard, "▶   Play / Pause") { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }
        addButton(mediaCard, "⏭   Next track") { mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT) }
        addButton(mediaCard, "⏮   Previous track") { mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }

        val volumeCard = card(content, "PHONE MEDIA VOLUME", "Changes your phone's media volume")
        volumeText = text("Volume", 14f, Color.WHITE, true)
        volumeCard.addView(volumeText)
        volumeBar = SeekBar(this).apply {
            max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    volumeText.text = "Volume: $progress / ${seekBar?.max ?: max}"
                    if (fromUser) audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        volumeCard.addView(volumeBar)
        val volumeButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addButton(volumeButtons, "− Volume") { adjustVolume(AudioManager.ADJUST_LOWER) }
        addButton(volumeButtons, "+ Volume") { adjustVolume(AudioManager.ADJUST_RAISE) }
        volumeCard.addView(volumeButtons)

        val guide = card(content, "EARBUD TOUCH GUIDE", "Gestures listed in the Mivi DuoPods Storm user manual")
        addGesture(guide, "Play / Pause", "Tap either earbud once")
        addGesture(guide, "Next track", "Tap the right earbud twice")
        addGesture(guide, "Previous track", "Tap the left earbud twice")
        addGesture(guide, "Gaming Mode", "Tap the left earbud three times")
        addGesture(guide, "Voice Assistant", "Tap the right earbud three times")
        addGesture(guide, "Volume down / up", "Press and hold left / right earbud")
        addGesture(guide, "Calls", "Tap either earbud once to answer or end")

        val note = text(
            "Important: Gaming Mode and touch gestures are operated directly on the earbuds. The user manual does not provide an app control protocol for changing these settings. Battery percentage is shown only if Android reports it.",
            12f, muted
        )
        note.setPadding(dp(4), dp(14), dp(4), dp(8))
        content.addView(note)
        content.addView(text("Unofficial app. Not affiliated with or endorsed by Mivi.", 11f, muted))
        root.addView(scroll, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)
        updateVolumeLabel()
    }

    private fun addGap(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun card(parent: LinearLayout, title: String, subtitle: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(card)
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.bottomMargin = dp(14)
        parent.addView(box, params)
        box.addView(text(title, 16f, accent, true))
        box.addView(text(subtitle, 12f, muted))
        addGap(box, 6)
        return box
    }

    private fun addButton(parent: LinearLayout, title: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = title
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(39, 54, 74), 12)
            setOnClickListener { action() }
            minHeight = dp(46)
            setPadding(dp(8), 0, dp(8), 0)
        }
        val params = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        params.setMargins(dp(3), dp(4), dp(3), dp(4))
        parent.addView(button, params)
    }

    private fun addGesture(parent: LinearLayout, label: String, detail: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        row.addView(text(label, 14f, Color.WHITE, true))
        row.addView(text(detail, 12f, muted))
        parent.addView(row)
    }

    private fun updateVolumeLabel() {
        if (::volumeText.isInitialized) {
            volumeText.text = "Volume: ${audio.getStreamVolume(AudioManager.STREAM_MUSIC)} / ${audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)}"
        }
        if (::volumeBar.isInitialized) volumeBar.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
    }

    private fun adjustVolume(direction: Int) {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        updateVolumeLabel()
    }

    private fun mediaKey(code: Int) {
        val now = android.os.SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0))
        Toast.makeText(this, "Media command sent", Toast.LENGTH_SHORT).show()
    }

    private fun requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 41)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41) refreshDeviceInfo()
    }

    private fun registerBatteryReceiver() {
        val filter = IntentFilter("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(batteryReceiver, filter)
    }

    private fun refreshDeviceInfo() {
        try {
            val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
            val adapter: BluetoothAdapter? = manager.adapter
            if (adapter == null) {
                statusText.text = "This phone does not support Bluetooth."
                return
            }
            if (!adapter.isEnabled) {
                statusText.text = "Bluetooth is turned off. Turn it on, then refresh."
                return
            }
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                statusText.text = "Allow Nearby devices permission, then refresh."
                return
            }
            val found = adapter.bondedDevices?.any { it.name == deviceName } == true
            statusText.text = if (found) "✓ Paired: $deviceName" else "Not paired yet. Pair $deviceName in Bluetooth settings."
        } catch (_: SecurityException) {
            statusText.text = "Bluetooth permission is required."
        } catch (_: Exception) {
            statusText.text = "Could not read Bluetooth status. Open Bluetooth settings to check."
        }
    }

    override fun onResume() {
        super.onResume()
        if (::audio.isInitialized) updateVolumeLabel()
        if (::statusText.isInitialized) refreshDeviceInfo()
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
