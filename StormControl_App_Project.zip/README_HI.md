# Storm Control (Unofficial Android companion)

Mivi DuoPods Storm के लिए एक lightweight Android companion app.

## Features
- Paired Bluetooth device `Mivi DuoPods Storm` की स्थिति दिखाता है।
- Bluetooth permission और Bluetooth settings खोलने का विकल्प।
- Standard Android media commands: Play/Pause, Next, Previous।
- फोन का media volume slider और +/- controls।
- User manual के अनुसार earbud touch gestures की quick guide।
- Android battery-level broadcast उपलब्ध होने पर battery percentage दिखाने की कोशिश।

## Important limitations
- Gaming Mode को earbuds पर बाएँ earbud को तीन बार tap करके चालू करें।
- Voice Assistant के लिए दाएँ earbud को तीन बार tap करें।
- Next/Previous और volume gestures सीधे earbuds पर काम करते हैं।
- Manual में app-to-earbud proprietary control protocol नहीं दिया गया है, इसलिए ऐप से Gaming Mode, EQ या touch remapping बदलने का दावा नहीं किया जाता।
- हर Android फोन/earbud battery broadcast उपलब्ध नहीं कराता।

## Build
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21

Android Studio में project खोलें और `app` का debug APK build करें। इस environment में Android SDK/Gradle उपलब्ध न होने के कारण APK compile/device-test नहीं किया गया है।

यह unofficial app है; Mivi से संबद्ध या endorsed नहीं है।
