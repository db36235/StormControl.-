plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "in.dhirendra.stormcontrol"
    compileSdk = 35
    defaultConfig {
        applicationId = "in.dhirendra.stormcontrol"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
